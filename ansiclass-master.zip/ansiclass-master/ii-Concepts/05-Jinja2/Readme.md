Jinja2 , a control structure controls the flow of engine parsing the template.

These structures includes coditions, loops , macros

control structure appear inside {% ... %}

condition :- decision maker

{% if ansible_facts['distribution'] == "*Microsoft*" %}

for more info and examples 
https://docs.ansible.com/ansible/latest/user_guide/playbooks_templating.html
  